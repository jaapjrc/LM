let x = 2
try {
    let y = x + i
} catch (error) {
    alert(error.message)
} finally {
    alert("Échale un vistazo al código anda")
}