function info(){
    document.write("<h1>Ejemplo 12 - Información de la pantalla</h1>")
    document.write(screen.height)
    document.write("<br> <br>")
    document.write(screen.availHeight)
    document.write("<br> <br>")
    document.write(screen.width)
    document.write("<br> <br>")
    document.write(screen.availWidth)
}