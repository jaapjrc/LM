let date = new Date()
let day = date.getDate()
let month = date.getMonth()+1
let year = date.getFullYear()
let hour = date.getHours()
let minute = date.getMinutes()
let sec = date.getSeconds()
document.write(day,'<br>',month,'<br>',year,'<br>',hour,'<br>',minute,'<br>',sec)