function changeRed(){
    nodeList = document.querySelectorAll("h3")
    nodeList[1].setAttribute("style", "color:red;")
}