function changeRed(){
    document.querySelector("#segundo h3").setAttribute("style", "color:red;")
}