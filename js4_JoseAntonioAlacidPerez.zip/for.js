for(let n=1; n <= 20; ++n){
    document.write(n,"^2 = ", n*n, '<br>')
}